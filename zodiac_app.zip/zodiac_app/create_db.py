import sqlite3

conn = sqlite3.connect("zodiac.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS zodiac (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sign TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    description TEXT NOT NULL
)
""")

zodiac_data = [
    ("Aries", "03-21", "04-19", "Confident and energetic."),
    ("Taurus", "04-20", "05-20", "Reliable and patient."),
    ("Gemini", "05-21", "06-20", "Curious and adaptable."),
    ("Cancer", "06-21", "07-22", "Emotional and loyal."),
    ("Leo", "07-23", "08-22", "Creative and confident."),
    ("Virgo", "08-23", "09-22", "Analytical and kind."),
    ("Libra", "09-23", "10-22", "Diplomatic and fair."),
    ("Scorpio", "10-23", "11-21", "Passionate and brave."),
    ("Sagittarius", "11-22", "12-21", "Optimistic and honest."),
    ("Capricorn", "12-22", "01-19", "Disciplined and ambitious."),
    ("Aquarius", "01-20", "02-18", "Innovative and independent."),
    ("Pisces", "02-19", "03-20", "Compassionate and artistic.")
]

cursor.executemany(
    "INSERT INTO zodiac (sign, start_date, end_date, description) VALUES (?, ?, ?, ?)",
    zodiac_data
)

conn.commit()
conn.close()

print("Database created successfully!")
