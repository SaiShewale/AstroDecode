from flask import Flask, render_template, request
import sqlite3

# Create Flask app FIRST
app = Flask(__name__)

# Function to get zodiac sign from database
def get_zodiac(month_day):
    conn = sqlite3.connect("zodiac.db")
    cursor = conn.cursor()

    cursor.execute("SELECT sign, start_date, end_date, description FROM zodiac")
    rows = cursor.fetchall()
    conn.close()

    for sign, start, end, description in rows:
        # Normal case
        if start <= month_day <= end:
            return sign, description

        # Capricorn cross-year case
        if start > end:
            if month_day >= start or month_day <= end:
                return sign, description

    return "Invalid Date", ""

# Home Page
@app.route("/")
def home():
    return render_template("index.html")

# Result Page
@app.route("/result", methods=["POST"])
def result():
    birthdate = request.form["birthdate"]
    month_day = birthdate[5:]

    sign, description = get_zodiac(month_day)

    zodiac_symbols = {
        "Aries": "♈",
        "Taurus": "♉",
        "Gemini": "♊",
        "Cancer": "♋",
        "Leo": "♌",
        "Virgo": "♍",
        "Libra": "♎",
        "Scorpio": "♏",
        "Sagittarius": "♐",
        "Capricorn": "♑",
        "Aquarius": "♒",
        "Pisces": "♓"
    }

    symbol = zodiac_symbols.get(sign, "")

    return render_template(
        "result.html",
        sign=sign,
        description=description,
        sign_symbol=symbol
    )

# Run App
if __name__ == "__main__":
    app.run(debug=True)
